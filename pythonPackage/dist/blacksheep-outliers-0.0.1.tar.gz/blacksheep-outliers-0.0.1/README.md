# BlackSheep
## A tool for to evaluating differences within genome-wide datasets of cohort of samples. 

### Outliers

### BlackSheep
